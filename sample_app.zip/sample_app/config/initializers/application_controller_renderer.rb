# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = 'ff4769a9618834267c04454eef376f9e24cb695dac542c79eaa170982fc3afa1917b16754f671a6e4cae024ace291087664bad2f06bf57204771ba7028fb0634'